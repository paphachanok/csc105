import { useState } from 'react'
import reactLogo from './assets/react.svg'
import "./App.css";
import TodoPage from "./pages/TodoPage";

function App() {

  return (
	<div className='App'>
		<TodoPage />
	</div>
  )
}

export default App
