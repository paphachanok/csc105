import "./Profile.css";

function Profile() {
  return (
	<div className="layout">
		<img src="src/assets/Tong.jpg" alt="profile" />
		<h1 className="name" >Paphachanok Poti</h1>
		<hr></hr>
	</div>
  )
}

export default Profile
